require 'rubygems'
require 'eventmachine'
require 'pp'

TOKEN = open("/etc/levels/selfish-dragonfly.token").read.strip

module ReverseTTP
  class ReverseError < Exception; end;
  def receive_data data
    begin
    #send_data "you sent: #{data}"
      data.strip!
      data.reverse!
      data.strip!
      #data.gsub!(/\A\n\r/, "")
      if data =~ /GET\s+\/([^\s]*)\s+HTTP/
        if $1  == "token"
         send_data "HTTP/1.1 200 OK\r\n".reverse+"\r\n#{TOKEN.reverse}\r\n"
        else
          send_data "HTTP/1.1 404 NOT FOUND".reverse+"\r\n"
        end
      else
        raise ReverseError
      end
    rescue ReverseError => e
      send_data "HTTP/1.1 400 Bad request".reverse+"\r\n"
    ensure
      close_connection(true)
  end
  end
end

EventMachine::run {
  EventMachine::start_server "0.0.0.0", 20000, ReverseTTP
}

